numeros = [0] * 10
marcados = [False] * 10  # Marca quais já foram impressos

# Leitura dos números
for i in range(10):
    numeros[i] = int(input(f"Digite o {i+1}º número: "))

print("\nNúmeros em ordem crescente:")

for _ in range(10):  # encontrar o menor 10 vezes
    menor = None
    pos_menor = -1

    for i in range(10):
        if not marcados[i]:
            if menor is None or numeros[i] < menor:
                menor = numeros[i]
                pos_menor = i

    if pos_menor != -1:
        print(menor)
        marcados[pos_menor] = True  # marca como impresso
