quantidade = int(input("Quantas idades você deseja informar? "))

soma = 0

for i in range(quantidade):
    idade = int(input(f"Digite a {i+1}ª idade: "))
    soma += idade

media = soma / quantidade
print(f"\nA média das idades informadas é: {media:.2f}")