pares = 0
impares = 0

for i in range(10):
    num = int(input(f"Digite o {1+i}º número: "))
    if num % 2 == 0:
        pares += 1
    else:
        impares += 1
print(f"O total de pares entre os números inseridos é {pares}, já de impares é {impares}")