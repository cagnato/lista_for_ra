soma = 0

for i in range (2, 101, 2):
        soma += i

print(f"A soma dos números pares até 50 é {soma}")