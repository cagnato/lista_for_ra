n = int(input("Tamanho dos vetores: "))

entrada_a = input("Vetor A: ").split()
A = [int(x) for x in entrada_a]

entrada_b = input("Vetor B: ").split()
B = [int(x) for x in entrada_b]

C = [0] * n
for i in range(n):
    C[i] = A[i] + B[i]

print("Vetor C:", end=" ")
for valor in C:
    print(valor, end=" ")
