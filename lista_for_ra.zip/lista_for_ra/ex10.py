vetor = [2, 4, 7, 2, 3, 3, 1, 0, 2, 6]
contagem = {}

for num in vetor:
    if num in contagem:
        contagem[num] += 1
    else:
        contagem[num] = 1

mais_repetido = None
maior_frequencia = 0

for numero, frequencia in contagem.items():
    if frequencia > maior_frequencia:
        mais_repetido = numero
        maior_frequencia = frequencia

print(f"O número que mais se repete é {mais_repetido}, com {maior_frequencia} ocorrências.")

