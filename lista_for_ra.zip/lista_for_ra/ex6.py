intervalo = 0
fora = 0

for i in range(10):
    num = int(input(f"Digite o {1+i}º número: "))
    if num in range(10, 21):
        intervalo += 1
    else:
        fora += 1
print(f"O total de números dentro do intervalo de 10 a 20 é {intervalo}, já o total de números fora do intervalo é {fora}")