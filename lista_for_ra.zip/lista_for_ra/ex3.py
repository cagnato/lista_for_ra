numero = int(input("Digite um número inteiro entre 1 e 10: "))

if 1 <= numero <= 10:
    print(f"\nTabuada do {numero}:\n")
    for i in range(1, 11):
        resultado = numero * i
        print(f"{numero} x {i} = {resultado}")
else:
    print("Valor inválido! Digite um número entre 1 e 10.")
