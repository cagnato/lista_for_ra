texto = input("Digite um texto qualquer: ")
vogais = 'aeiou'
contador = {'a':0, 'e':0, 'i':0, 'o':0, 'u':0}

for letra in texto.lower():
    if letra in vogais:
        contador[letra] += 1

print("\nQuantidade de vogais:")
for vogal, quantidade in contador.items():
    if quantidade > 0:
        print(f"{vogal}: {quantidade}")
